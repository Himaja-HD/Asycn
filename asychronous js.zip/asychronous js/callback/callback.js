var prg = document.querySelector("#progress");
  const button = document.getElementById("Button");
  var progressContainer = document.querySelector("#load");
  const output = document.getElementById("output");

  function fetchData(callback) {
    setTimeout(() => {
      fetch("https://dummyjson.com/posts")
        .then((response) => response.json())
        .then((data) => callback(data.posts))
        .catch((error) => {
          console.error("Error fetching data:", error);
          output.textContent = "Failed to fetch data.";
        });
    }, 5000); // Simulate a delay
  }

  button.addEventListener("click", () => {
    // Hide the button
    button.style.display = "none";
    progressContainer.style.display = "block";

    // Display loading text
    output.textContent = "please wait...";

    let count = 0;
    const interval = setInterval(() => {
      count++;
      prg.style.width = count + "%";

      // Stop the interval when the progress bar reaches 100%
      if (count === 100) {
        clearInterval(interval);
      }
    }, 50);

    fetchData((posts) => {
      clearInterval(interval); // Ensure the interval stops when fetch is complete
      prg.style.width = "100%"; // Set progress to 100% on completion
      progressContainer.style.display = "none"; // Hide progress container
      output.innerHTML = posts.map((post) => `<p>${post.title}</p>`).join("");
    });
  });