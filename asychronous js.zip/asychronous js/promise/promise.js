const button = document.getElementById('Button');
const output = document.getElementById('output');


function fetchDataWithTimeout(url) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject("Operation timed out"), 5000); 
    fetch(url)
      .then(response => {
        clearTimeout(timer); 
        return response.ok ? response.json() : Promise.reject("Failed to fetch data");
      })
      .then(resolve) // Resolve with the data
      .catch(reject); // Reject with the error
  });
}

button.addEventListener('click', () => {
  button.style.display = "none"; 
  output.textContent = "Loading..."; 
  output.style.backgroundImage="linear-gradient(white,lightgrey)";

  fetchDataWithTimeout('https://dummyjson.com/posts') 
    .then(data => {
      output.innerHTML = data.posts.map(post => `<p>${post.title}</p>`).join(''); // Show posts
    })
    .catch(error => {
      output.innerHTML = `<span class="error">${error}</span>`; // Show error
    });
});
