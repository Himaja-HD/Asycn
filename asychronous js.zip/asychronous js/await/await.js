const button = document.getElementById('fetchButton'); 
const output = document.getElementById('output'); 


async function fetchData(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(url, { signal: controller.signal });  // Sends a fetch request linked to the controller for timeout handling.

    clearTimeout(timeout);

    if (!response.ok) throw new Error("Failed to fetch data"); // Throws an error if the response status is not OK.

    return await response.json();
    // Parses and returns response.
    // `await` ensures the function waits for the JSON parsing to complete.

  } catch (error) {
    clearTimeout(timeout);

    throw error.name === 'AbortError' ? new Error("Request timed out") : error;
    // If the error is caused by the fetch being aborted (`AbortError`), 
    // Throws a timeout error or the original error otherwise.
  }
}

button.addEventListener('click', async () => {
  button.style.display = "none";
  output.style.backgroundColor="rgb(246, 238, 240)";
  output.style.color="crimson";
  output.textContent = "Please wait...";
  output.style.height="350px";
  output.style.overflowY = "auto";

  try {
    const data = await fetchData('https://dummyjson.com/posts'); // Fetch post
    output.innerHTML = data.posts.map(post => `<p>${post.title}</p>`).join(''); // Display post
  } catch (error) {
    output.innerHTML = `<span class="error">${error.message}</span>`; 
  }
});
